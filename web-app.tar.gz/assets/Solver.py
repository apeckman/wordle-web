"""Hint engine: suggests the guess that tells you the most, the way NYT's WordleBot does.

For every guess it could suggest, the solver works out how that guess would split the
answers that are still possible into groups (one group per color pattern the guess could
show). A guess that leaves many small groups narrows things down far more than one that
leaves a single big group. That is measured as expected information (entropy, in bits),
summed over every unsolved board, so in Quordle one guess is scored on all boards at once.
"""
import math
from collections import Counter

GREEN, YELLOW, BLACK = 2, 1, 0
COLOR_CODES = {"green": GREEN, "yellow": YELLOW, "black": BLACK}

# A guess that might be the answer gets this many bits of credit per board, scaled by the
# chance it is right. It breaks ties toward words that could win now, and it makes the
# solver go for the answer once only two or three are left instead of "exploring".
WIN_BONUS = 1.0

# Best first guess for the bundled word list (computed with best_guess on the full list,
# which takes several seconds). Used when nothing is known yet and the word is available.
OPENER = "raise"


def pattern(guess, answer):
    """Wordle colors for guess against answer, packed into one int (base 3, green=2).

    Same rules as Board.score (repeated letters are only marked as often as they appear
    in the answer), written for speed because the solver calls it hundreds of thousands
    of times per hint.
    """
    if guess == answer:
        return 3 ** len(guess) - 1
    code = 0
    unmatched = []
    pending = []
    weight = 1
    for g, a in zip(guess, answer):
        if g == a:
            code += GREEN * weight
        else:
            unmatched.append(a)
            pending.append((g, weight))
        weight *= 3
    for g, weight in pending:
        if g in unmatched:
            code += YELLOW * weight
            unmatched.remove(g)
    return code


def pattern_from_colors(colors):
    code, weight = 0, 1
    for color in colors:
        code += COLOR_CODES[color] * weight
        weight *= 3
    return code


class Suggestion:
    """A scored guess. possible[i] = answers still possible on board i (None if solved)."""

    def __init__(self, word, possible, expected_left, worst_left):
        self.word = word
        self.possible = possible
        self.expected_left = expected_left  # board -> average answers left after this guess
        self.worst_left = worst_left        # board -> most answers that could be left

    def __repr__(self):
        return "Suggestion(%r)" % self.word


class Solver:
    def __init__(self, answers, guesses=None):
        """answers: every word that can be the secret word.
        guesses: words the solver may suggest (defaults to the answers, so hints are
        always familiar words rather than obscure dictionary entries)."""
        self.answers = list(answers)
        self.guesses = list(guesses) if guesses is not None else self.answers

    def candidates(self, history):
        """Answers consistent with history, a list of (guess, colors) already played."""
        words = self.answers
        for guess, colors in history:
            words = self.narrow(words, guess, colors)
        return words

    @staticmethod
    def narrow(words, guess, colors):
        """The words that would have shown these colors for this guess."""
        code = pattern_from_colors(colors)
        return [word for word in words if pattern(guess, word) == code]

    def best_guess(self, boards):
        """Best single guess across boards, a list of candidate lists (None for solved boards).

        Returns a Suggestion, or None if some unsolved board has no possible answers left
        (only happens if the secret word isn't in the answer list).
        """
        live = [(i, possible) for i, possible in enumerate(boards) if possible is not None]
        if not live or any(not possible for _, possible in live):
            return None

        # Nothing learned yet anywhere: use the precomputed opener instead of a slow search.
        if OPENER in self.guesses and all(len(possible) == len(self.answers) for _, possible in live):
            return self._suggest(OPENER, boards)

        # A board with exactly one answer left: playing it solves that board for sure and
        # still gives information on the others. Pick the one that helps the rest most.
        sure = sorted({possible[0] for _, possible in live if len(possible) == 1})
        pool = sure or self.guesses

        best_word, best_score = None, -1.0
        for guess in pool:
            score = 0.0
            for _, possible in live:
                score += self._score(guess, possible)
            if score > best_score + 1e-9:
                best_word, best_score = guess, score
        return self._suggest(best_word, boards)

    @staticmethod
    def _score(guess, possible):
        n = len(possible)
        if n == 1:
            return WIN_BONUS if possible[0] == guess else 0.0
        groups = Counter(pattern(guess, answer) for answer in possible)
        entropy = math.log2(n) - sum(size * math.log2(size) for size in groups.values()) / n
        if guess in possible:
            entropy += WIN_BONUS / n
        return entropy

    @staticmethod
    def _suggest(word, boards):
        expected, worst = {}, {}
        for i, possible in enumerate(boards):
            if possible is None:
                continue
            groups = Counter(pattern(word, answer) for answer in possible)
            groups.pop(3 ** len(word) - 1, None)  # guessing it right leaves nothing
            expected[i] = sum(size * size for size in groups.values()) / len(possible)
            worst[i] = max(groups.values(), default=0)
        return Suggestion(word, boards, expected, worst)
