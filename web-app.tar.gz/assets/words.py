"""Word lists, bundled in Media/ so the game behaves the same on every computer (and in a browser).

- Media/word_bank: the possible answers (2,315 words).
- Media/valid_guesses: every word accepted as a guess (14,855 words, answers included), the
  standard Wordle list from https://github.com/tabatkins/wordle-list.
"""
import os
import sys

WORD_LENGTH = 5


def resource_path(rel_path):
    """Find a bundled file whether running from source or from a PyInstaller build."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel_path)


def _read(name):
    with open(resource_path(os.path.join("Media", name)), "r") as f:
        return [line.strip().lower() for line in f if line.strip()]


def load_word_bank():
    return _read("word_bank")


def load_dictionary(word_bank):
    """Valid guesses: the bundled guess list plus every possible answer."""
    return sorted(set(_read("valid_guesses")) | set(word_bank))
