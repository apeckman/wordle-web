"""Seeding Python's random module so each game gets fresh words.

On a computer Python seeds itself from the operating system, so this isn't needed. In a web
browser (pygbag) it starts from the same state on every page load, which made the first game
always the same word (DICEY). gui.py calls seed_random() at startup there.
"""
import random
import time


def browser_entropy():
    """Random numbers from the browser (JavaScript's Math.random and clock), or () elsewhere."""
    try:
        import platform  # in pygbag this is the bridge to the browser's JavaScript
        window = platform.window
        return int(window.Math.random() * 2 ** 52), int(window.Date.now())
    except Exception:
        return ()


def seed_random(rng=random, entropy=None):
    """Seed rng (the random module by default) from browser entropy plus the clock.

    Returns the seed material, so the same sequence can be reproduced with rng.seed(repr(...)).
    """
    material = (browser_entropy() if entropy is None else entropy, time.time_ns(), time.perf_counter_ns())
    rng.seed(repr(material))
    return material
