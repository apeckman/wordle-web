"""Graphical version of the game, built with pygame.

Run:  .venv/bin/python gui.py      (one-time setup: pip install -r requirements.txt)
The terminal version (python3 main.py) still works without pygame.

Controls: type letters, Enter to guess, Backspace to delete. The Hint button fills in the
guess that narrows things down the most; press Enter to play it. In Quordle, Hint first asks
which: all boards (1 guess for every unsolved board) or one board (also: keys 1-4, or tap a board
while choosing). Boards never give a hint from a tap alone.
"""
import asyncio
import math
import os
import random
import sys
import threading

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
try:
    import pygame
except ImportError:
    sys.exit("The GUI needs pygame: pip install -r requirements.txt\n"
             "(or play the terminal version with: python3 main.py)")

from Board import PRIORITY
from Game import Game, InvalidGuess, board_names
from Solver import Solver
from words import load_dictionary, load_word_bank

# Running in a web browser (built with pygbag, see web/). No threads, no system fonts there.
WEB = sys.platform == "emscripten"
WEB_WIDTH = 600  # points; the page scales the canvas to fit the browser window
WEB_STATUS_BLUR = 40  # CSS px below the iPhone status bar that iOS blurs in home-screen web apps

WINDOW_SIZE = (740, 840)
MIN_SIZE = (520, 640)
FPS = 60

# Palette
BG = (21, 25, 36)
PANEL = (33, 38, 54)
TEXT = (236, 239, 244)
DARK_TEXT = (21, 25, 36)
MUTED = (140, 148, 170)
EMPTY_BORDER = (50, 56, 76)
TYPED_BORDER = (112, 120, 146)
KEY = (76, 83, 106)
BUTTON = (50, 57, 80)
ACCENT = (46, 160, 107)
TILE_COLORS = {
    "green": (46, 160, 107),
    "yellow": (222, 168, 52),
    "black": (56, 60, 76),
}

# Animation timings (milliseconds)
FLIP_MS = 280
FLIP_STAGGER_MS = 140
POP_MS = 110
SHAKE_MS = 450
BOUNCE_MS = 420
BOUNCE_STAGGER_MS = 80
TOAST_MS = 1800
HINT_TOAST_MS = 4500
RESULT_SLIDE_MS = 300

KEY_ROWS = [list("qwertyuiop"), list("asdfghjkl"), ["enter"] + list("zxcvbnm") + ["back"]]

WIN_MESSAGES = {1: "Unreal!", 2: "Brilliant!", 3: "Superb!", 4: "Nice work!", 5: "Solid!", 6: "Phew, close one!"}


def clamp01(x):
    return max(0.0, min(1.0, x))


def ease_out(p):
    return 1 - (1 - p) ** 3


def lighten(color, amount):
    return tuple(min(255, int(v + (255 - v) * amount)) for v in color)


ICON_LETTERS = "ALEX"
APP_NAME = "Wordle"


def set_macos_app_name(name):
    """Show `name` instead of "Python" in the macOS menu bar.

    The game runs inside Python.app, so macOS uses that bundle's name. Changing the name in the
    bundle's info dictionary before the window (and NSApplication) exists makes the menu bar use
    ours. Uses ctypes to call the Objective-C runtime, so it needs no extra packages. Best effort:
    any failure just leaves the name as "Python".
    """
    if sys.platform != "darwin":
        return
    try:
        import ctypes
        import ctypes.util

        objc = ctypes.cdll.LoadLibrary(ctypes.util.find_library("objc"))
        ctypes.cdll.LoadLibrary(ctypes.util.find_library("Foundation"))
        objc.objc_getClass.restype = ctypes.c_void_p
        objc.objc_getClass.argtypes = [ctypes.c_char_p]
        objc.sel_registerName.restype = ctypes.c_void_p
        objc.sel_registerName.argtypes = [ctypes.c_char_p]
        msg_send = ctypes.cast(objc.objc_msgSend, ctypes.c_void_p).value

        def send(receiver, selector, *args, restype=ctypes.c_void_p, argtypes=()):
            # objc_msgSend must be called through a prototype matching each call (required on Apple silicon).
            fn = ctypes.CFUNCTYPE(restype, ctypes.c_void_p, ctypes.c_void_p, *argtypes)(msg_send)
            return fn(receiver, objc.sel_registerName(selector), *args)

        def ns_string(text):
            return send(objc.objc_getClass(b"NSString"), b"stringWithUTF8String:", text.encode(),
                        argtypes=(ctypes.c_char_p,))

        bundle = send(objc.objc_getClass(b"NSBundle"), b"mainBundle")
        info = send(bundle, b"infoDictionary")
        if info:
            send(info, b"setObject:forKey:", ns_string(name), ns_string("CFBundleName"),
                 restype=None, argtypes=(ctypes.c_void_p, ctypes.c_void_p))
    except Exception:
        pass


def make_icon(fonts, size=512, full_bleed=False):
    """App icon drawn in code: a 2x2 grid of game tiles spelling ICON_LETTERS on a dark rounded square.

    full_bleed: an opaque square with no border, for phones (iOS rounds the corners itself and
    turns transparent corners black)."""
    icon = pygame.Surface((size, size), pygame.SRCALPHA)
    if full_bleed:
        body = icon.get_rect()
        icon.fill(BG)
    else:
        margin = round(size * 0.09)  # macOS icons leave a little transparent border
        body = pygame.Rect(margin, margin, size - 2 * margin, size - 2 * margin)
        pygame.draw.rect(icon, BG, body, border_radius=round(body.w * 0.22))
        pygame.draw.rect(icon, EMPTY_BORDER, body, max(2, size // 128), border_radius=round(body.w * 0.22))

    gap = round(body.w * 0.06)
    tile = (body.w - 2 * round(body.w * 0.13) - gap) // 2
    x0 = body.centerx - tile - gap // 2
    y0 = body.centery - tile - gap // 2
    for i, (letter, color) in enumerate(zip(ICON_LETTERS, ("green", "yellow", "black", "green"))):
        cell = pygame.Rect(x0 + (i % 2) * (tile + gap), y0 + (i // 2) * (tile + gap), tile, tile)
        pygame.draw.rect(icon, TILE_COLORS[color], cell, border_radius=round(tile * 0.16))
        label = fonts.render(letter, tile * 0.62, TEXT)
        icon.blit(label, label.get_rect(center=cell.center))
    return icon


class Fonts:
    NAMES = "avenirnext,helveticaneue,helvetica,arial"

    def __init__(self):
        self._fonts = {}
        self._text = {}

    def get(self, size, bold=True):
        key = (max(8, int(size)), bold)
        if key not in self._fonts:
            self._fonts[key] = pygame.font.SysFont(self.NAMES, key[0], bold=bold)
        return self._fonts[key]

    def render(self, text, size, color, bold=True):
        key = (text, int(size), color, bold)
        surface = self._text.get(key)
        if surface is None:
            if len(self._text) > 3000:
                self._text.clear()
            surface = self.get(size, bold).render(text, True, color)
            self._text[key] = surface
        return surface


_safe_area_probe = None


def safe_area():
    """(top, bottom) CSS pixels the game must stay clear of: the notch/status bar and the home
    indicator when it runs full-screen from an iPhone home screen (zero in a normal browser tab).
    Add ?safe=47,34 to the URL to fake them for testing on a computer."""
    global _safe_area_probe
    import platform
    win = platform.window
    fake = str(win.location.search)
    if "safe=" in fake:
        top, bottom = fake.split("safe=")[1].split("&")[0].split(",")
        return float(top), float(bottom)
    if _safe_area_probe is None:
        # CSS knows the insets (env(safe-area-inset-*)); JavaScript can only read them off an element.
        _safe_area_probe = win.document.createElement("div")
        _safe_area_probe.style.cssText = ("position:fixed;top:0;left:0;visibility:hidden;pointer-events:none;"
                                          "padding-top:env(safe-area-inset-top);"
                                          "padding-bottom:env(safe-area-inset-bottom)")
        win.document.body.appendChild(_safe_area_probe)
    style = win.getComputedStyle(_safe_area_probe)
    return float(str(style.paddingTop).replace("px", "") or 0), float(str(style.paddingBottom).replace("px", "") or 0)


def touch_screen():
    """True in a browser on a phone or tablet (no mouse to hover, no keyboard to press W or Q)."""
    if not WEB:
        return False
    try:
        import platform
        return bool(platform.window.matchMedia("(pointer: coarse)").matches)
    except Exception:
        return False


def home_screen_app(win):
    """True when launched from an iPhone home-screen icon (add ?standalone=1 to fake it)."""
    try:
        return bool(win.navigator.standalone) or "standalone=1" in str(win.location.search)
    except Exception:
        return False


def seed_random_from_browser():
    """In the browser, Python's random module starts from the same state on every page load, so
    the first game always had the same word. Seed it from the browser's randomness and the clock."""
    import time
    try:
        import platform
        browser = (int(platform.window.Math.random() * 2 ** 52), int(platform.window.Date.now()))
    except Exception:
        browser = ()
    random.seed(repr((browser, time.time_ns(), time.perf_counter_ns())))


def browser_view():
    """(width, height, pixel ratio, safe top, safe bottom) of the browser window in CSS pixels,
    or None outside a browser."""
    try:
        import platform  # pygbag's bridge to JavaScript
        win = platform.window
        try:
            top, bottom = safe_area()
        except Exception:
            top = bottom = 0.0
        if home_screen_app(win):
            # iOS blurs and fades a band below the status bar in home-screen web apps, so keep
            # the header clear of it (the page may start below the status bar, so top can be 0).
            top += WEB_STATUS_BLUR
        return win.innerWidth, win.innerHeight, win.devicePixelRatio or 1, top, bottom
    except Exception:
        return None


def web_canvas_size(view):
    """Layout size in points for the browser (WEB_WIDTH wide, shaped like the browser window), pixels
    per point so the canvas has as many pixels as it covers on screen (sharp on Retina), and the
    safe-area insets (top, bottom) in points."""
    css_w, css_h, dpr, top, bottom = view or (WEB_WIDTH, WEB_WIDTH * 1.4, 1, 0, 0)
    points = (WEB_WIDTH, int(min(1300, max(MIN_SIZE[1] * 1.25, WEB_WIDTH * css_h / css_w))))
    shown = min(css_w / points[0], css_h / points[1])  # the page scales the canvas to fit
    return points, max(1.0, min(3.0, shown * dpr)), (top / shown, bottom / shown)


class App:
    def __init__(self):
        set_macos_app_name(APP_NAME)  # must happen before pygame sets up the window system
        if WEB:
            seed_random_from_browser()
            # Just graphics and text: starting the sound system makes browsers show a "playing audio" icon.
            pygame.display.init()
            pygame.font.init()
        else:
            pygame.init()
        # Use a taller window when the screen has room (bigger Quordle tiles).
        screen_h = pygame.display.Info().current_h
        size = (WINDOW_SIZE[0], max(MIN_SIZE[1], min(960, screen_h - 120)) if screen_h > 0 else WINDOW_SIZE[1])
        self.fonts = Fonts()
        icon = make_icon(self.fonts)

        # All layout below is in "points" (what the window size and mouse use). On a Retina screen
        # pygame-ce gives us a surface with 2 pixels per point; self.scale converts at draw time.
        if WEB:
            # A fixed canvas shaped like the browser window (tall on a phone), scaled to fit by the page.
            self.window = None
            self.web_view = browser_view()
            self.web_resize = None  # (new view, when first seen) while the browser window is changing
            self.web_frames = 0
            self.apply_web_canvas()
        elif hasattr(pygame, "Window"):  # pygame-ce
            self.window = pygame.Window("Wordle / Quordle", size, resizable=True, allow_high_dpi=True)
            self.window.minimum_size = MIN_SIZE
            self.window.set_icon(icon)
        else:  # original pygame: works, but draws at 1x (soft on Retina)
            self.window = None
            pygame.display.set_caption("Wordle / Quordle")
            pygame.display.set_icon(icon)
            pygame.display.set_mode(size, pygame.RESIZABLE)
        self.begin_frame()
        pygame.key.set_repeat(350, 40)
        self.clock = pygame.time.Clock()

        self.word_bank = load_word_bank()
        dictionary = load_dictionary(self.word_bank)
        self.dictionary = set(dictionary)
        self.solver = Solver(self.word_bank)

        self.clickables = []  # (rect, action(now), name) registered by the last draw
        self.shown_enter_tip = False
        self.touch = touch_screen()
        self.last_touch = -10000  # when the last FINGERDOWN arrived (to drop its emulated mouse click)
        self.drag = None          # a finger scrolling the words-left list
        self.word_list_area = None
        self.mode = None
        self.words = None
        self.go_to_menu()

    # ----- state changes -------------------------------------------------

    def go_to_menu(self):
        self.scene = "menu"
        self.game = None
        self.thinking = None
        self.word_list = None
        self.hint_picker = False
        self.timers = []
        self.toasts = []

    def start(self, mode, words=None):
        self.mode = mode
        count = 1 if mode == "w" else 4
        self.words = list(words) if words else random.sample(self.word_bank, count)
        self.game = Game(self.words, self.dictionary, self.solver)
        self.scene = "game"
        self.typed = ""
        self.toasts = []
        self.timers = []
        self.reveal = None       # {"start": ms, "rows": {board_index: row_index}} while tiles flip
        self.shake_start = None
        self.pop = None          # (tile_index, start_ms) for the letter just typed
        self.bounces = {}        # board_index -> start_ms of its "solved" bounce
        self.result_at = None    # when the end-of-game panel appeared
        self.board_grid = (1, 1)
        self.thinking = None     # {"board", "guesses", "result"} while a hint is computed off-thread
        self.shown_hint = None   # the Hint whose word is in the typed row, for highlighting its boards
        self.hint_hover = False  # mouse is over the Hint button (Quordle previews which boards it covers)
        self.word_list = None    # {"board", "row", "scroll"} while the words-left list replaces the keyboard
        self.hint_picker = False  # Quordle: the "hint for which board?" chooser is open

    def later(self, when, callback):
        self.timers.append((when, callback))

    def run_timers(self, now):
        due = [t for t in self.timers if t[0] <= now]
        self.timers = [t for t in self.timers if t[0] > now]
        for _, callback in due:
            callback(now)

    def toast(self, text, now, duration=TOAST_MS):
        self.toasts = [t for t in self.toasts if now - t[1] < t[2]][-2:] + [(text, now, duration)]

    def accepting_input(self):
        return self.scene == "game" and not self.game.over and self.reveal is None

    def type_letter(self, letter, now):
        if self.accepting_input() and len(self.typed) < self.game.word_length:
            self.typed += letter
            self.pop = (len(self.typed) - 1, now)

    def backspace(self, now=None):
        if self.accepting_input():
            self.typed = self.typed[:-1]

    def submit(self, now):
        if not self.accepting_input():
            return
        game = self.game
        try:
            guess = game.check(self.typed)
        except InvalidGuess as error:
            self.toast(str(error), now)
            self.shake_start = now
            return

        rows_before = [len(board.guesses) for board in game.boards]
        newly_solved = game.submit(guess)
        self.reveal = {
            "start": now,
            "rows": {i: rows_before[i] for i, board in enumerate(game.boards) if len(board.guesses) > rows_before[i]},
        }
        self.typed = ""
        self.pop = None
        self.hint_picker = False
        done = now + FLIP_STAGGER_MS * (game.word_length - 1) + FLIP_MS
        self.later(done, lambda t: self.finish_reveal(t, newly_solved))

    def finish_reveal(self, now, newly_solved):
        self.reveal = None
        for i in newly_solved:
            self.bounces[i] = now
        multi = len(self.game.boards) > 1
        if self.game.over:
            delay = BOUNCE_MS + BOUNCE_STAGGER_MS * self.game.word_length if newly_solved else 350
            self.later(now + delay, self.show_result)
        elif newly_solved and multi:
            names = " and ".join(str(i + 1) for i in newly_solved)
            self.toast("Board %s solved!" % names, now)

    def show_result(self, now):
        self.result_at = now

    def hint(self, now, board_index=None):
        """Ask the solver for a hint. It can take up to a second, so it runs on a thread
        (in a browser, where there are no threads, it runs right after "Thinking..." is drawn)."""
        if not self.accepting_input() or self.thinking:
            return
        job = {"board": board_index, "guesses": len(self.game.guesses), "game": self.game,
               "result": None, "done": False, "polls": 0}
        self.thinking = job

        def work():
            try:
                job["result"] = job["game"].hint(board_index)
            except Exception:
                pass  # treated like no hint; never leave the button stuck on "thinking"
            finally:
                job["done"] = True

        if WEB:
            job["work"] = work
        else:
            threading.Thread(target=work, daemon=True).start()

    def hint_button(self, now):
        """Wordle: hint straight away. Quordle: open (or close) the chooser, so a board-only hint
        never comes from a stray tap on a board."""
        if len(self.game.boards) == 1:
            self.hint(now)
        elif self.accepting_input() and not self.thinking:
            self.hint_picker = not self.hint_picker
            self.toasts = []  # the chooser uses the message strip

    def pick_hint(self, now, board_index=None):
        """From the chooser: None = best guess for all unsolved boards, else just that board."""
        self.hint_picker = False
        self.hint(now, board_index)

    def open_word_list(self, board_index, row):
        """Show (or, clicking the same count again, hide) the words left after a row."""
        current = self.word_list
        if current and (current["board"], current["row"]) == (board_index, row):
            self.word_list = None
        else:
            self.word_list = {"board": board_index, "row": row, "scroll": 0}

    def pick_word(self, word, now):
        if self.accepting_input():
            self.typed = word
            self.pop = None

    def close_word_list(self, now=None):
        self.word_list = None

    def poll_hint(self, now):
        job = self.thinking
        if job and "work" in job and not job["done"]:
            job["polls"] += 1
            if job["polls"] >= 2:  # one frame showing "Thinking..." has been drawn
                job["work"]()
        if not job or not job["done"]:
            return
        self.thinking = None
        hint = job["result"]
        # Drop it if the player moved on (new game, or guessed) while it was computing.
        if hint is None or job["game"] is not self.game or job["guesses"] != len(self.game.guesses):
            return
        if not self.accepting_input():
            return
        if hint.word is None:
            self.toast(hint.explain(), now)
            return
        self.typed = hint.word
        self.pop = None
        self.shown_hint = hint
        if self.shown_enter_tip:
            self.toast(hint.explain(), now, HINT_TOAST_MS)
        else:
            self.shown_enter_tip = True
            self.toast(hint.explain() + ". Enter plays it", now, HINT_TOAST_MS)

    # ----- events --------------------------------------------------------

    def handle_event(self, event, now):
        if event.type == pygame.QUIT:
            return False
        if event.type == pygame.VIDEORESIZE and self.window is None:
            w, h = max(MIN_SIZE[0], event.w), max(MIN_SIZE[1], event.h)
            if (w, h) != (event.w, event.h):
                pygame.display.set_mode((w, h), pygame.RESIZABLE)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if WEB and (getattr(event, "touch", False) or now - self.last_touch < 600):
                # Browsers report a tap twice: as a touch, then as an emulated mouse click. The
                # FINGERDOWN below already handled it (and Hint toggles, so twice would undo it).
                return True
            pos = (event.pos[0] / self.scale, event.pos[1] / self.scale - self.offset_y) if WEB else event.pos
            if self.word_list and self.word_list_area and self.word_list_area.collidepoint(pos):
                self.drag = {"start": pos, "scroll": self.word_list["scroll"], "moved": False, "mouse": True}
            else:
                self.click(pos, now)
        elif event.type == pygame.MOUSEMOTION and self.drag and self.drag.get("mouse") and self.word_list:
            pos = (event.pos[0] / self.scale, event.pos[1] / self.scale - self.offset_y) if WEB else event.pos
            self.drag_to(pos)
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.drag and self.drag.get("mouse"):
            self.end_drag(now)
        elif event.type == pygame.FINGERDOWN and WEB:
            # Phone taps: use the touch position itself (x/y are 0-1 across the canvas) rather than
            # the browser's emulated mouse, whose position can lag behind.
            self.last_touch = now
            pos = self.finger_pos(event)
            area = self.word_list_area if self.word_list else None
            if area and area.collidepoint(pos):
                # In the words-left list a finger can drag to scroll, so wait for it to lift: a tap
                # (little movement) picks the word under it, a drag only scrolls.
                self.drag = {"start": pos, "scroll": self.word_list["scroll"], "moved": False}
            else:
                self.click(pos, now)
        elif event.type == pygame.FINGERMOTION and WEB and self.drag and not self.drag.get("mouse") and self.word_list:
            self.drag_to(self.finger_pos(event))
        elif event.type == pygame.FINGERUP and WEB and self.drag and not self.drag.get("mouse"):
            self.last_touch = now
            self.end_drag(now)
        elif event.type == pygame.MOUSEWHEEL and self.word_list:
            self.word_list["scroll"] -= event.y * 24
        elif event.type == pygame.KEYDOWN:
            self.handle_key(event, now)
        return True

    def drag_to(self, pos):
        """Scroll the words-left list with a dragging finger (or mouse)."""
        dy = pos[1] - self.drag["start"][1]
        if abs(dy) > 8:
            self.drag["moved"] = True
        if self.drag["moved"]:
            self.word_list["scroll"] = self.drag["scroll"] - dy

    def end_drag(self, now):
        """Lifting without having dragged is a tap: pick the word under it."""
        drag, self.drag = self.drag, None
        if not drag["moved"] and self.word_list:
            self.click(drag["start"], now)

    def finger_pos(self, event):
        """A touch event's position in points (event.x/y are 0-1 across the whole canvas)."""
        full_w, full_h = self.full_screen.get_size()
        return (event.x * full_w / self.scale, event.y * full_h / self.scale - self.offset_y)

    def click(self, pos, now):
        for rect, action, _name in reversed(self.clickables):
            if rect.collidepoint(pos):
                action(now)
                break

    def handle_key(self, event, now):
        if event.mod & (pygame.KMOD_META | pygame.KMOD_CTRL):
            return  # leave Cmd/Ctrl shortcuts (like Cmd+Q) to the system
        if pygame.K_a <= event.key <= pygame.K_z:
            char = chr(event.key)
        else:
            char = event.unicode.lower() if getattr(event, "unicode", "") else ""
        enter = event.key in (pygame.K_RETURN, pygame.K_KP_ENTER)

        if self.word_list:
            if event.key in (pygame.K_DOWN, pygame.K_PAGEDOWN):
                self.word_list["scroll"] += 24 if event.key == pygame.K_DOWN else 96
                return
            if event.key in (pygame.K_UP, pygame.K_PAGEUP):
                self.word_list["scroll"] -= 24 if event.key == pygame.K_UP else 96
                return
            # Any other key puts the keyboard back; typing carries on as normal.
            self.close_word_list()
            if event.key == pygame.K_ESCAPE:
                return

        if self.hint_picker and self.scene == "game":
            if char in "1234" and char and not self.game.boards[int(char) - 1].solved:
                self.pick_hint(now, int(char) - 1)
                return
            if enter:
                self.pick_hint(now)
                return
            self.hint_picker = False  # any other key closes it; Esc does nothing else
            if event.key == pygame.K_ESCAPE:
                return

        if self.scene == "menu":
            if char in ("w", "q"):
                self.start(char)
            return

        if self.result_at is not None:
            if enter or char == "n":
                self.start(self.mode)
            elif char == "r":
                self.start(self.mode, self.words)
            elif char == "m" or event.key == pygame.K_ESCAPE:
                self.go_to_menu()
            return

        if enter:
            self.submit(now)
        elif event.key == pygame.K_BACKSPACE:
            self.backspace(now)
        elif len(char) == 1 and "a" <= char <= "z":
            self.type_letter(char, now)

    def run(self):
        running = True
        while running:
            running = self.frame()
            self.clock.tick(FPS)
        pygame.quit()

    async def run_async(self):
        """The same loop for the browser, which needs control back after every frame."""
        while self.frame():
            self.clock.tick(FPS)
            await asyncio.sleep(0)

    def apply_web_canvas(self):
        points, self.web_scale, self.web_insets = web_canvas_size(self.web_view)
        pygame.display.set_mode((round(points[0] * self.web_scale), round(points[1] * self.web_scale)))

    def check_web_resize(self, now):
        """Rebuild the canvas when the browser window changes size (or moves to a screen with a
        different pixel ratio), once it has stayed put for a moment, so it stays sharp."""
        self.web_frames += 1
        if self.web_frames % 10:
            return  # asking the browser every frame is wasteful
        view = browser_view()
        if view is None or view == self.web_view:
            self.web_resize = None
            return
        if self.web_resize is None or self.web_resize[0] != view:
            self.web_resize = (view, now)
        elif now - self.web_resize[1] >= 250:
            self.web_view, self.web_resize = view, None
            self.apply_web_canvas()
            try:
                import platform
                platform.window.window_resize()  # the page re-fits the canvas to the window
            except Exception:
                pass

    def frame(self):
        now = pygame.time.get_ticks()
        if WEB:
            self.check_web_resize(now)
        running = True
        for event in pygame.event.get():
            if not self.handle_event(event, now):
                running = False
        self.run_timers(now)
        self.poll_hint(now)
        self.draw(now)
        self.present()
        return running

    def present(self):
        if self.window is not None:
            self.window.flip()
        else:
            pygame.display.flip()

    # ----- drawing helpers -----------------------------------------------
    # Callers work in points; these helpers convert to real pixels with self.scale.

    def begin_frame(self):
        """Grab the window surface (it changes on resize) and work out pixels per point."""
        if self.window is not None:
            self.screen = self.window.get_surface()
            points_w = self.window.size[0]
        else:
            self.screen = pygame.display.get_surface()
            points_w = self.screen.get_width() / (self.web_scale if WEB else 1)
        self.scale = self.screen.get_width() / points_w if points_w else 1.0
        self.full_screen = self.screen
        self.offset_y = 0
        if WEB and any(self.web_insets):
            # Draw everything inside the iPhone safe area: a sub-surface below the notch and above
            # the home indicator. Layout code never knows; clicks are shifted to match.
            top = round(self.web_insets[0] * self.scale)
            bottom = round(self.web_insets[1] * self.scale)
            w, h = self.screen.get_size()
            self.screen = self.screen.subsurface((0, top, w, max(1, h - top - bottom)))
            self.offset_y = top / self.scale
        pixels_w, pixels_h = self.screen.get_size()
        self.size =(round(pixels_w / self.scale), round(pixels_h / self.scale))

    def mouse(self):
        """Mouse position in points (in the browser, pygame reports canvas pixels), used for hover
        effects. Touch screens have no hover: the browser parks the "mouse" where the last tap was,
        which would leave something lit up, so report it as nowhere (taps use event positions)."""
        if self.touch:
            return (-10000, -10000)
        x, y = pygame.mouse.get_pos()
        return (x / self.scale, y / self.scale - self.offset_y) if WEB else (x, y)

    def px(self, value):
        return int(round(value * self.scale))

    def px_rect(self, rect):
        """A rect in points -> the same rect in pixels (edges rounded, so neighbors don't gap)."""
        x, y, w, h = rect
        s = self.scale
        left, top = round(x * s), round(y * s)
        return pygame.Rect(left, top, max(1, round((x + w) * s) - left), max(1, round((y + h) * s) - top))

    def rrect(self, color, rect, radius, width=0, **corners):
        corners = {k: self.px(v) for k, v in corners.items()}
        pygame.draw.rect(self.screen, color, self.px_rect(rect), max(1, self.px(width)) if width else 0,
                         border_radius=self.px(radius), **corners)

    def text(self, text, size, color, center=None, bold=True, **anchor):
        surface = self.fonts.render(text, size * self.scale, color, bold)
        if center:
            rect = surface.get_rect(center=(self.px(center[0]), self.px(center[1])))
        else:
            (name, value), = anchor.items()
            value = tuple(self.px(v) for v in value) if isinstance(value, tuple) else self.px(value)
            rect = surface.get_rect(**{name: value})
        self.screen.blit(surface, rect)
        # Where it landed, back in points.
        return pygame.Rect(rect.x / self.scale, rect.y / self.scale, rect.w / self.scale, rect.h / self.scale)

    def button(self, rect, label, action, size=17, primary=False, enabled=True):
        rect = pygame.Rect(rect)
        hovered = enabled and rect.collidepoint(self.mouse())
        color = ACCENT if primary else BUTTON
        if not enabled:
            color = PANEL
        elif hovered:
            color = lighten(color, 0.12)
        self.rrect(color, rect, 10)
        self.text(label, size, TEXT if enabled else MUTED, center=rect.center)
        if enabled:
            self.clickables.append((rect, action, "button:" + label))
        return rect

    def draw_tile(self, cell, letter, state, scale=1.0, scale_y=1.0):
        """state: "empty", "typed", or a score color ("green", "yellow", "black")."""
        # Work straight in pixels here so flips and pops animate smoothly at Retina resolution.
        s = self.scale
        rect = pygame.Rect(0, 0, max(1, int(cell.w * s * scale)), max(1, int(cell.h * s * scale * scale_y)))
        rect.center = (round(cell.centerx * s), round(cell.centery * s))
        radius = self.px(max(3, cell.w // 7))
        border = self.px(max(2, cell.w // 24))
        if state == "empty":
            pygame.draw.rect(self.screen, EMPTY_BORDER, rect, border, border_radius=radius)
        elif state == "typed":
            pygame.draw.rect(self.screen, PANEL, rect, border_radius=radius)
            pygame.draw.rect(self.screen, TYPED_BORDER, rect, border, border_radius=radius)
        else:
            pygame.draw.rect(self.screen, TILE_COLORS[state], rect, border_radius=radius)
        if letter and scale_y > 0.12:
            surface = self.fonts.render(letter.upper(), cell.h * 0.56 * s, TEXT)
            if scale_y < 1:
                size = (surface.get_width(), max(1, int(surface.get_height() * scale_y)))
                surface = pygame.transform.smoothscale(surface, size)
            self.screen.blit(surface, surface.get_rect(center=rect.center))

    # ----- menu ----------------------------------------------------------

    def draw(self, now):
        self.clickables = []
        self.begin_frame()
        self.full_screen.fill(BG)
        if self.scene == "menu":
            self.draw_menu(now)
        else:
            self.draw_game(now)
        self.draw_toasts(now)

    def draw_menu(self, now):
        w, h = self.size
        title = "WORDLE"
        colors = ["green", "black", "yellow", "black", "green", "yellow"]
        tile, gap = 62, 8
        total = len(title) * tile + (len(title) - 1) * gap
        top = int(h * 0.16)
        for i, (letter, color) in enumerate(zip(title, colors)):
            bob = math.sin(now / 420 + i * 0.7) * 5
            cell = pygame.Rect(w // 2 - total // 2 + i * (tile + gap), top + bob, tile, tile)
            self.draw_tile(cell, letter, color)
        self.text("& QUORDLE", 22, MUTED, center=(w // 2, top + tile + 34))

        card_w, card_h = min(420, w - 64), 96
        y = top + tile + 90
        for key, name, detail in (("w", "Wordle", "One word, six guesses"),
                                  ("q", "Quordle", "Four words at once, nine guesses")):
            rect = pygame.Rect(w // 2 - card_w // 2, y, card_w, card_h)
            hovered = rect.collidepoint(self.mouse())
            self.rrect(lighten(PANEL, 0.08) if hovered else PANEL, rect, 16)
            if hovered:
                self.rrect(ACCENT, rect, 16, 2)
            self.text(name, 28, TEXT, topleft=(rect.x + 26, rect.y + 18))
            self.text(detail, 16, MUTED, bold=False, topleft=(rect.x + 26, rect.y + 58))
            if not self.touch:  # keyboard shortcut badge; no keyboard on a phone
                badge = pygame.Rect(0, 0, 44, 44)
                badge.midright = (rect.right - 24, rect.centery)
                self.rrect(BUTTON, badge, 10)
                self.text(key.upper(), 20, TEXT, center=badge.center)
            self.clickables.append((rect, lambda now, key=key: self.start(key), "menu:" + key))
            y += card_h + 18

        if not self.touch:
            self.text("Press W or Q to start", 15, MUTED, bold=False, center=(w // 2, y + 26))

    # ----- game screen ---------------------------------------------------

    def draw_game(self, now):
        w, h = self.size
        header_h = 64
        self.draw_header(w, header_h)

        keyboard_h = min(186, int(h * 0.25))
        keyboard = pygame.Rect(16, h - keyboard_h - 16, w - 32, keyboard_h)
        # Messages get their own strip under the header so they never cover a board.
        strip = pygame.Rect(16, header_h + 6, w - 32, 30)
        area = pygame.Rect(16, strip.bottom + 14, w - 32, keyboard.y - strip.bottom - 28)
        self.draw_boards(now, area)
        self.draw_message_strip(now, strip)

        # The words-left list takes the keyboard's spot (like the result panel) so the boards stay visible.
        if self.word_list:
            self.draw_word_list(keyboard)
        elif self.result_at is not None:
            self.draw_result(now, keyboard)
        else:
            self.draw_keyboard(keyboard)

    def draw_word_list(self, panel):
        """Every answer that was still possible after one guess on one board, in place of the keyboard."""
        info = self.word_list
        board, row = info["board"], info["row"]
        words = self.game.possible_after(board, row + 1)
        guess = self.game.boards[board].history()[row][0]

        self.rrect(PANEL, panel, 14)
        where = "Board %d, after " % (board + 1) if len(self.game.boards) > 1 else "After "
        title = self.text(where + guess.upper(), 17, TEXT, topleft=(panel.x + 16, panel.y + 14))
        noun = "word" if len(words) == 1 else "words"
        self.text("%d possible %s" % (len(words), noun), 14, MUTED, bold=False,
                  midleft=(title.right + 12, title.centery))
        self.button((panel.right - 16 - 72, panel.y + 9, 72, 30), "Close", self.close_word_list, size=14)

        area = self.word_list_area = pygame.Rect(panel.x + 16, panel.y + 48, panel.w - 40, panel.h - 48 - 8)
        col_w, line_h = 74, 24
        cols = max(1, area.w // col_w)
        col_w = area.w / cols
        lines = (len(words) + cols - 1) // cols
        content_h = lines * line_h
        info["scroll"] = max(0, min(info["scroll"], content_h - area.h))
        scroll = info["scroll"]

        self.screen.set_clip(self.px_rect(area))
        first = int(scroll // line_h)
        mouse = self.mouse()
        pickable = self.accepting_input()
        for n in range(first * cols, min(len(words), (first + area.h // line_h + 2) * cols)):
            word = words[n]
            x = area.x + (n % cols) * col_w
            y = area.y + (n // cols) * line_h - scroll
            cell = pygame.Rect(x - 6, y + 1, col_w - 6, line_h - 2)
            hit = cell.clip(area)
            chosen = self.typed == word
            hovered = pickable and hit.collidepoint(mouse)
            if chosen or hovered:
                self.rrect(ACCENT if chosen else BUTTON, cell, 6)
            self.text(word.upper(), 15, TEXT, bold=chosen, topleft=(x, y + 3))
            if pickable and hit.h > 0:
                # Clicking a word types it in, like a hint; Enter plays it.
                self.clickables.append((hit, lambda now, word=word: self.pick_word(word, now), "word:" + word))
        self.screen.set_clip(None)

        if content_h > area.h:
            # Scrollbar so it's obvious there's more.
            track = pygame.Rect(panel.right - 12, area.y, 4, area.h)
            thumb_h = max(24, area.h * area.h / content_h)
            thumb = pygame.Rect(track.x, area.y + (area.h - thumb_h) * scroll / (content_h - area.h), 4, thumb_h)
            self.rrect(BUTTON, track, 2)
            self.rrect(MUTED, thumb, 2)

    def draw_header(self, w, h):
        game = self.game
        bw = 84 if w >= 640 else 62
        self.button((16, 14, bw, 36), "Menu", lambda now: self.go_to_menu(), size=16)
        self.button((w - 16 - bw, 14, bw, 36), "New", lambda now: self.start(self.mode), size=16)
        if not self.accepting_input():
            self.hint_picker = False
        hint_rect = self.hint_rect = self.button((w - 24 - 2 * bw, 14, bw, 36), "Hint", self.hint_button, size=16,
                                                 primary=self.hint_picker,
                                                 enabled=self.accepting_input() and not self.thinking)
        self.hint_hover = (len(game.boards) > 1 and self.accepting_input() and not self.thinking
                           and not self.hint_picker and hint_rect.collidepoint(self.mouse()))

        self.text("WORDLE" if self.mode == "w" else "QUORDLE", 26, TEXT, center=(w // 2, 25))
        if game.over:
            status = ""
        elif game.remaining_guesses == 1:
            status = "1 guess left. Don't get nervous!"
        else:
            status = "%d guesses left" % game.remaining_guesses
        if status:
            self.text(status, 14, MUTED, bold=False, center=(w // 2, 50))
        self.rrect(EMPTY_BORDER, (0, h, w, 1), 0)

    def draw_message_strip(self, now, strip):
        """The hint chooser if it's open, else the newest message, else a quiet line about what's hovered."""
        if self.hint_picker:
            self.draw_hint_picker(strip)
            return
        live = [t for t in self.toasts if now - t[1] < t[2]]
        if live:
            text, start, duration = live[-1]
            pill = self.make_pill(text, strip.w)
            fade = duration - (now - start)
            if fade < 300:
                pill.set_alpha(int(255 * fade / 300))
            self.screen.blit(pill, pill.get_rect(center=self.px_rect(strip).center))
            return
        if self.thinking:
            label = "Thinking..."
        elif self.hint_hover:
            label = "Hint: choose all boards or just one"
        else:
            return
        self.text(label, 14, MUTED, bold=False, center=strip.center)

    def draw_hint_picker(self, strip):
        """Hint for: [All boards] [1] [2] [3] [4] [Cancel], centered in the message strip."""
        h = 28
        items = [("All boards", 96, lambda now: self.pick_hint(now), True)]
        for i, board in enumerate(self.game.boards):
            items.append((str(i + 1), 38, lambda now, i=i: self.pick_hint(now, i), not board.solved))
        items.append(("Cancel", 72, lambda now: setattr(self, "hint_picker", False), True))
        label_w, gap = 66, 6
        total = label_w + sum(width for _, width, _, _ in items) + gap * len(items)
        x = strip.centerx - total // 2
        self.text("Hint for", 14, MUTED, bold=False, midleft=(x, strip.centery))
        x += label_w + gap
        for label, width, action, enabled in items:
            self.button((x, strip.centery - h // 2, width, h), label, action, size=14,
                        primary=label == "All boards", enabled=enabled)
            x += width + gap

    def board_layout(self, area):
        game = self.game
        n, rows, cols = len(game.boards), game.max_guesses, game.word_length
        gap_ratio, board_gap = 0.12, 26
        count_ratio = 1.0  # room right of each board for the "words left" counts, in tiles
        cap = 66 if n == 1 else 46
        grids = [(1, 1)] if n == 1 else [(2, 2), (4, 1)]

        best = None
        for gx, gy in grids:
            tile_w = (area.w - board_gap * (gx - 1)) / gx / (cols + gap_ratio * (cols - 1) + count_ratio)
            tile_h = (area.h - board_gap * (gy - 1)) / gy / (rows + gap_ratio * (rows - 1))
            tile = int(min(tile_w, tile_h, cap))
            # Prefer the 2x2 grid unless the single row gives clearly bigger tiles.
            if best is None or tile > best[0] * 1.15:
                best = (tile, gx, gy)
        tile, gx, gy = best

        gap = max(3, round(tile * gap_ratio))
        board_w = cols * tile + (cols - 1) * gap
        board_h = rows * tile + (rows - 1) * gap
        count_w = round(tile * count_ratio)
        slot_w = board_w + count_w
        total_w = gx * slot_w + (gx - 1) * board_gap
        total_h = gy * board_h + (gy - 1) * board_gap
        # Wordle keeps its board centered with the counts hanging off the side; Quordle centers board + counts.
        x0 = area.centerx - (board_w // 2 if n == 1 else total_w // 2)
        y0 = area.centery - total_h // 2
        rects = [pygame.Rect(x0 + (i % gx) * (slot_w + board_gap), y0 + (i // gx) * (board_h + board_gap),
                             board_w, board_h) for i in range(n)]
        self.board_grid = (gx, gy)
        return rects, tile, gap

    def bouncing(self, board_index, now):
        start = self.bounces.get(board_index)
        return start is not None and now - start < BOUNCE_MS + BOUNCE_STAGGER_MS * self.game.word_length

    def board_done(self, board_index):
        """Solved, and its winning row has finished flipping."""
        revealing = self.reveal is not None and board_index in self.reveal["rows"]
        return self.game.boards[board_index].solved and not revealing

    def draw_boards(self, now, area):
        rects, tile, gap = self.board_layout(area)
        multi = len(rects) > 1
        mouse = self.mouse()
        hint = self.shown_hint if self.shown_hint and self.typed == self.shown_hint.word else None
        if hint is None:
            self.shown_hint = None
        for i, (board, rect) in enumerate(zip(self.game.boards, rects)):
            hit = rect.inflate(gap * 2 + 10, gap * 2 + 10)
            if multi and self.accepting_input() and not board.solved:
                thinking_here = self.thinking and self.thinking["board"] == i
                if self.hint_picker or thinking_here:
                    # While choosing a hint, every open board is a target (tap one for a hint on just it).
                    self.rrect(PANEL, hit, 12)
                    if self.hint_picker and hit.collidepoint(mouse):
                        self.rrect(TYPED_BORDER, hit, 12, 2)
                if self.hint_picker:
                    self.clickables.append((hit, lambda now, i=i: self.pick_hint(now, i), "board:%d" % (i + 1)))
            if multi and hint and i in (hint.sure_boards or hint.possible):
                # Outline the boards the hint in the typed row was chosen for.
                self.rrect(ACCENT, hit, 12, 2)

            self.draw_board(now, i, board, rect, tile, gap)

            # Dim finished boards while play continues; show everything at full strength once it's over.
            if multi and self.board_done(i) and not self.bouncing(i, now) and self.result_at is None:
                area_px = self.px_rect(rect.inflate(8, 8))
                shade = pygame.Surface(area_px.size, pygame.SRCALPHA)
                shade.fill(BG + (150,))
                self.screen.blit(shade, area_px)

    def draw_board(self, now, board_index, board, rect, tile, gap):
        game = self.game
        rows = board.rows()
        reveal_row = self.reveal["rows"].get(board_index) if self.reveal else None
        input_row = len(rows) if not board.solved and not game.over else None

        shake = 0
        if self.shake_start is not None:
            p = (now - self.shake_start) / SHAKE_MS
            if p < 1:
                shake = math.sin(p * math.pi * 6) * tile * 0.18 * (1 - p)
            else:
                self.shake_start = None

        for r in range(game.max_guesses):
            y = rect.y + r * (tile + gap)
            for c in range(game.word_length):
                cell = pygame.Rect(rect.x + c * (tile + gap), y, tile, tile)
                if r < len(rows):
                    letter, color = rows[r][c]
                    if r == reveal_row:
                        p = clamp01((now - self.reveal["start"] - c * FLIP_STAGGER_MS) / FLIP_MS)
                        if p <= 0:
                            self.draw_tile(cell, letter, "typed")
                        else:
                            self.draw_tile(cell, letter, "typed" if p < 0.5 else color,
                                           scale_y=abs(math.cos(math.pi * p)) if p < 1 else 1)
                    else:
                        if r == len(rows) - 1 and self.bouncing(board_index, now):
                            p = clamp01((now - self.bounces[board_index] - c * BOUNCE_STAGGER_MS) / BOUNCE_MS)
                            cell = cell.move(0, -math.sin(math.pi * p) * tile * 0.3)
                        self.draw_tile(cell, letter, color)
                elif r == input_row:
                    letter = self.typed[c] if c < len(self.typed) else ""
                    scale = 1.0
                    if self.pop and self.pop[0] == c:
                        p = (now - self.pop[1]) / POP_MS
                        if p < 1:
                            scale = 1 + 0.1 * math.sin(math.pi * p)
                    self.draw_tile(cell.move(shake, 0), letter, "typed" if letter else "empty", scale=scale)
                else:
                    self.draw_tile(cell, "", "empty")

            if r < len(rows) and r != reveal_row:
                self.draw_count(board_index, r, rect.right + gap, y, tile)

    def draw_count(self, board_index, row, x, y, tile):
        """How many answers were still possible after this row's guess; click to list them."""
        count = len(self.game.possible_after(board_index, row + 1))
        size = min(18, max(11, round(tile * 0.42)))
        label = str(count)
        text_w = self.fonts.render(label, size * self.scale, MUTED).get_width() / self.scale
        pill = pygame.Rect(x, 0, max(text_w + 10, size * 1.7), size + 8)
        pill.centery = y + tile // 2
        hovered = pill.collidepoint(self.mouse())
        active = self.word_list and (self.word_list["board"], self.word_list["row"]) == (board_index, row)
        if active or hovered:
            self.rrect(ACCENT if active else BUTTON, pill, pill.h // 2)
        self.text(label, size, TEXT if active or hovered else MUTED, center=pill.center)
        self.clickables.append((pill.inflate(4, 4), lambda now: self.open_word_list(board_index, row),
                                "count:%d:%d" % (board_index + 1, row + 1)))

    def key_colors(self):
        """For each board, letter -> best color seen so far (ignoring tiles still flipping)."""
        result = []
        for i, board in enumerate(self.game.boards):
            rows = board.rows()
            if self.reveal and i in self.reveal["rows"]:
                rows = rows[:self.reveal["rows"][i]]
            colors = {}
            for row in rows:
                for letter, color in row:
                    if PRIORITY[color] > PRIORITY[colors.get(letter, "gray")]:
                        colors[letter] = color
            result.append(colors)
        return result

    def draw_keyboard(self, area):
        gap = 6
        key_h = int(min(58, (area.h - 2 * gap) / 3))
        width = min(area.w, 640)
        key_w = (width - 9 * gap) / 10
        top = area.bottom - 3 * key_h - 2 * gap
        colors = self.key_colors()
        enabled = self.accepting_input()

        for r, row in enumerate(KEY_ROWS):
            widths = [key_w * 1.55 if k in ("enter", "back") else key_w for k in row]
            x = area.centerx - (sum(widths) + gap * (len(row) - 1)) / 2
            y = top + r * (key_h + gap)
            for key, key_width in zip(row, widths):
                rect = pygame.Rect(round(x), y, round(key_width), key_h)
                self.draw_key(rect, key, colors, enabled)
                x += key_width + gap

    def draw_key(self, rect, key, colors, enabled):
        hovered = enabled and rect.collidepoint(self.mouse())
        radius = 8

        def shade(color):
            return lighten(color, 0.14) if hovered else color

        if key in ("enter", "back"):
            self.rrect(shade(KEY), rect, radius)
            self.text("ENTER" if key == "enter" else "DEL", min(16, rect.h * 0.3), TEXT, center=rect.center)
            action = self.submit if key == "enter" else self.backspace
        else:
            boards = self.game.boards
            # In Quordle, a finished board's slice goes back to plain once its last row has flipped.
            per_board = [None if len(boards) > 1 and self.board_done(i) else colors[i].get(key)
                         for i in range(len(boards))]
            if len(boards) == 1:
                self.rrect(shade(TILE_COLORS.get(per_board[0], KEY)), rect, radius)
            else:
                # One slice per board, laid out like the boards on screen.
                gx, gy = self.board_grid
                for i, color in enumerate(per_board):
                    cx, cy = i % gx, i // gx
                    x0, x1 = rect.x + rect.w * cx // gx, rect.x + rect.w * (cx + 1) // gx
                    y0, y1 = rect.y + rect.h * cy // gy, rect.y + rect.h * (cy + 1) // gy
                    self.rrect(
                        shade(TILE_COLORS.get(color, KEY)), (x0, y0, x1 - x0, y1 - y0), 0,
                        border_top_left_radius=radius if cx == 0 and cy == 0 else 0,
                        border_top_right_radius=radius if cx == gx - 1 and cy == 0 else 0,
                        border_bottom_left_radius=radius if cx == 0 and cy == gy - 1 else 0,
                        border_bottom_right_radius=radius if cx == gx - 1 and cy == gy - 1 else 0,
                    )
            self.text(key.upper(), min(22, rect.h * 0.4), TEXT, center=rect.center)
            action = lambda now, key=key: self.type_letter(key, now)

        if enabled:
            self.clickables.append((rect, action, "key:" + key))

    def draw_result(self, now, area):
        game = self.game
        slide = ease_out(clamp01((now - self.result_at) / RESULT_SLIDE_MS))
        card = area.move(0, int((1 - slide) * 30))
        self.rrect(PANEL, card, 18)

        used = len(game.guesses)
        if game.won:
            if len(game.boards) == 1:
                title, detail = WIN_MESSAGES.get(used, "Winner!"), "Solved in %d of %d guesses" % (used, game.max_guesses)
            else:
                title, detail = "All four solved!", "Finished with %d guesses to spare" % game.remaining_guesses
        else:
            solved = sum(board.solved for board in game.boards)
            title = "Out of guesses"
            if len(game.boards) == 1:
                detail = "The word was %s" % game.words[0].upper()
            else:
                detail = "Solved %d of 4.  Answers: %s" % (solved, "  ".join(
                    "%d %s" % (i + 1, word.upper()) for i, word in enumerate(game.words)))

        self.text(title, 28, TEXT, center=(card.centerx, card.y + 36))
        self.text(detail, 16, MUTED, bold=False, center=(card.centerx, card.y + 70))

        bw, bh, gap = 150, 44, 12
        y = card.y + 100
        x = card.centerx - (3 * bw + 2 * gap) // 2
        self.button((x, y, bw, bh), "New game", lambda now: self.start(self.mode), primary=True)
        replay = "Replay word" if len(game.words) == 1 else "Replay words"
        self.button((x + bw + gap, y, bw, bh), replay, lambda now: self.start(self.mode, self.words))
        self.button((x + 2 * (bw + gap), y, bw, bh), "Menu", lambda now: self.go_to_menu())
        if card.bottom - (y + bh) > 26:
            self.text("Enter: new game   R: replay   Esc: menu", 13, MUTED, bold=False,
                      center=(card.centerx, y + bh + 22))

    def draw_toasts(self, now):
        """Floating messages for the menu (the game screen shows them in its message strip)."""
        self.toasts = [t for t in self.toasts if now - t[1] < t[2]]
        if self.scene == "game":
            return
        w, y = self.size[0], 20
        for text, start, duration in self.toasts:
            pill = self.make_pill(text, w - 32)
            fade = duration - (now - start)
            if fade < 300:
                pill.set_alpha(int(255 * fade / 300))
            self.screen.blit(pill, pill.get_rect(midtop=(self.px(w / 2), self.px(y))))
            y += pill.get_height() / self.scale + 8

    def make_pill(self, text, max_w):
        """A message pill in pixels, shrinking the font if needed so it fits max_w points."""
        size = 16
        while True:
            label = self.fonts.render(text, size * self.scale, DARK_TEXT)
            if label.get_width() + self.px(30) <= self.px(max_w) or size <= 11:
                break
            size -= 1
        pill = pygame.Surface((label.get_width() + self.px(30), self.px(28)), pygame.SRCALPHA)
        pygame.draw.rect(pill, TEXT, pill.get_rect(), border_radius=pill.get_height() // 2)
        pill.blit(label, label.get_rect(center=pill.get_rect().center))
        return pill

if __name__ == "__main__":
    App().run()
