"""Browser entry point. pygbag needs a main.py with an async loop; build_web.py copies this in."""
import asyncio

import pygame  # noqa: F401  (pygbag decides which packages to load from main.py's imports)

import gui

TITLE = "Wordle & Quordle"


def document():
    import platform  # pygbag's bridge to the browser's JavaScript
    return platform.window.document


def style_page():
    """Match the page to the game (no gray bars beside the canvas) and give iPhones a home-screen icon."""
    try:
        doc = document()
        doc.body.style.background = "#151924"
        for rel in ("apple-touch-icon", "icon"):
            link = doc.createElement("link")
            link.rel = rel
            link.href = "favicon.png"
            doc.head.appendChild(link)
        meta = doc.createElement("meta")
        meta.name = "apple-mobile-web-app-capable"
        meta.content = "yes"
        doc.head.appendChild(meta)
    except Exception:
        pass  # cosmetic only


def set_title():
    """The tab title, which iPhones also use as the home-screen name."""
    try:
        if document().title != TITLE:
            document().title = TITLE
    except Exception:
        pass


async def main():
    app = gui.App()
    style_page()
    frames = 0
    while app.frame():
        app.clock.tick(gui.FPS)
        frames += 1
        if frames % 30 == 1:  # the browser's SDL layer renames the tab "pygame window" once it draws
            set_title()
        await asyncio.sleep(0)


asyncio.run(main())
