"""Browser entry point. pygbag needs a main.py with an async loop; build_web.py copies this in."""
import asyncio

import pygame  # noqa: F401  (pygbag decides which packages to load from main.py's imports)

import gui


def style_page():
    """Match the page to the game (no gray bars beside the canvas) and give iPhones a home-screen icon."""
    try:
        import platform  # pygbag's bridge to the browser's JavaScript
        document = platform.window.document
        document.body.style.background = "#151924"
        document.title = "Wordle & Quordle"
        for rel in ("apple-touch-icon", "icon"):
            link = document.createElement("link")
            link.rel = rel
            link.href = "favicon.png"
            document.head.appendChild(link)
        meta = document.createElement("meta")
        meta.name = "apple-mobile-web-app-capable"
        meta.content = "yes"
        document.head.appendChild(meta)
    except Exception:
        pass  # cosmetic only


async def main():
    style_page()
    await gui.App().run_async()


asyncio.run(main())
